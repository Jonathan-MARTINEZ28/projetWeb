<Instructions>
	**SVP N'oubliez pas d'extraire le ficher.zip avant d'ouvrir le html :)**
        1-  Tapez sur la lune pour activer le Night Mode;
        2-  Vous pouvez télécharger mon code source "Code.zip" à la fin de Home Page;
        3-  J'ai hébergé mon site et le lien c'est : https://zekri2.000webhostapp.com/,
                Mais j'ai enlevé tous les informations personnelles;
        4-  À Sud-Est dans les longues pages, il y a "top" qui permet de remonter en haut de la page.
        5- <copyright>
                <informations>
                        tous les informations de ma ville et de mon lycée existe sur Wikipedia
                                & J'ai écrit "Cliquez Bibliothèque" où href="Wikipedia"
                </informations>                
                <Photos>
                        :)> src="me8.jpg" c'est mon photo </:) 
                        <Photoshop>
                                Mon logo src="icon1.png" -> je l'ai fait en Photoshop 
                                        == "AF" -> Adham Fawzi && Fawzi 3ème prénom,
                                & "fig1.png" & "fig2.png" & "space.png" & "icon.png"
                                        & "chance.png" & "write.png";
                        </Photoshop>
                        Tous les photos jpg et png qui n'ont pas appellé en <Photoshop> & <:)>
                                je les ai téléchargé du Google Images
                                        et j'ai fait des modifications dans la plupart des photos,
                        <modification>
                                c++> 
                                        rien || changement des couleurs || 
                                                (changement des couleurs && mettre une cercle dèrrière le photo originale)
                                        <sauf> 
                                                src="full.jpg" j'ai fait quelque modifications lisible :)
                                                        & src="tapez.jpg" modifications lisible :) 
                                        </sauf>
                                <c++
                        </modification>
                </Photos>
        </copyright>
        6- Le but du page "Login" c'est par exemple, dans mon site peut-être je peux expliquer de html,c++,... donc tu dois
                faire un compte chez moi pour voir les videos "€", et etc ... il ya bcp des exemples.
        7- donc le but de CV dans cette cas c'est pour savoir mes compétences d'abord avant "€" :) et etc ....
	8- donc le but de Contact c pour une demande "travail que le client demande" mais l'opinion c pour
		tous le monde donne leur opinion sur mon site et etc ...                                   
</Instructions>



